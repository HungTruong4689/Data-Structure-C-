#pragma once

int main_1(); // main function for searching method
int main_2(); // main function for sorting method


